#include "plant.hh"

void plant::set_attributes (){
}

void plant::initialize(){
	num(0) = 1.0;
	den(0) = 0;
	den(1) = 13;
	den(2) = 1;

}

void plant::processing (){
	y_out.write( ltf_nd( num, den, k_input.read(), 1 ) );
}
