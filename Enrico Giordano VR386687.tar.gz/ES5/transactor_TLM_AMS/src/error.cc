#include "error.hh"

error::error(sc_core::sc_module_name nm) :
        r("r"), y("y"), e("e") {
}

void error::set_attributes() {
    e.set_delay(1.0);
}

void error::initialize(){
	e.initialize(0.0);
}
void error::processing() {
	std::cout<< "[ ERROR ]  READ" << r.read() << std::endl;
    e.write(( r.read() - y.read() ), 0 );
    std::cout<< "[ ERROR ]  WRITE" << ( r.read() - y.read() ) <<std::endl;
}
