#include "testbench_TLM.hh"


testbench_TLM::testbench_TLM(sc_module_name name): sc_module(name){

  initiator_socket(*this);
  SC_THREAD(run);


	ifstream infile("input_reference.txt");
   
    if (!infile.is_open()) {
        cerr << "[ TB ] There was a problem opening the input file 1!\n";
        exit(1);
    }

    double num = 0.0;
    while (infile >> num) {
        testbench_TLM::input_reference.push_back(num);
    }
}


void testbench_TLM::run(){

  sc_core::sc_time local_time;
  iostruct packet;
  tlm::tlm_generic_payload payload;	

  local_time = m_qk.get_local_time();
  cout << "[ TB ] size :"<<sc_simulation_time()<<" - "<<name()<<" - run"<< endl;
  for(uint32_t i=0; i< input_reference.size(); i++)
  {
		packet.r = testbench_TLM::input_reference[i] ;
		
		payload.set_data_ptr((unsigned char*) &packet);
		payload.set_address(0); // set address, 0 here since we have only 1 target and 1 initiator 
		payload.set_write(); // write transaction
		
		local_time = m_qk.get_local_time();
		cout<<"[ TB ] WRITING "<<packet.r <<endl;
		cout<<"[ TB ] " << i <<" Invoking the b_transport primitive - write"<<endl;
		initiator_socket->b_transport(payload, local_time);
		
		
		// start read transaction
		payload.set_read();
		initiator_socket->b_transport(payload, local_time);
		
		
		if(payload.get_response_status() == tlm::TLM_OK_RESPONSE){
			cout<<"[ TB ] TLM protocol correctly implemented"<<endl;
			cout<<"[ TB ] READING " << packet.y << endl;
		}
		
		
		cout << "[ TB ] Time: " << sc_time_stamp() << " + " << local_time << endl;
		m_qk.set(local_time);
		if (m_qk.need_sync()) {
			cout << "SYNCHRONIZING" << endl;
			m_qk.sync();
			cout << "#####################" << endl;
		}
	  wait(40,SC_MS);
  }
  
  sc_stop();
}


void testbench_TLM::invalidate_direct_mem_ptr(uint64 start_range, uint64 end_range)
{
  
}

tlm::tlm_sync_enum testbench_TLM::nb_transport_bw(tlm::tlm_generic_payload &  trans, tlm::tlm_phase &  phase, sc_time &  t)
{
  return tlm::TLM_COMPLETED;
}