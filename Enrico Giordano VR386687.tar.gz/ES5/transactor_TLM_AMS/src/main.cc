#include "testbench_TLM.hh"
#include "tlm_2_rtl.hh"
#include "rtl_2_tdf.hh"
#include "error.hh"
#include "controller.hh"
#include "plant.hh"


//#define TRACE_PLANT
#define TABULAR_FILE "plant.dat"

SC_MODULE(topl)
{
	testbench_TLM testbench;
	tlm_2_rtl i_tlm2rtl;
	rtl_2_tdf i_rtl2tdf;
	error i_error;
	controller i_controller;
	plant i_plant;

	sc_core::sc_signal < double >  r_rtl;
	sc_core::sc_signal < double >  y_rtl;
	
	
	sca_tdf::sca_signal<double> r;
	sca_tdf::sca_signal<double> e;
	sca_tdf::sca_signal<double> k;
	sca_tdf::sca_signal<double> y;

	SC_CTOR(topl)
    : testbench("testbench")
    , i_tlm2rtl("i_tlm2rtl")
    , i_rtl2tdf("i_rtl2tdf")
    , i_error("i_error")
    , i_controller("i_controller")
    , i_plant("i_plant")
  {

  i_tlm2rtl.r( r_rtl );
  i_tlm2rtl.y( y_rtl );

  i_rtl2tdf.r_rtl( r_rtl );
  i_rtl2tdf.y_rtl( y_rtl );
  
  i_rtl2tdf.r_tdf( r );
  i_rtl2tdf.y_tdf( y );
  
  i_error.r( r );
  i_error.y( y );
  i_error.e ( e );
  
  i_controller.e( e );
  i_controller.k( k );
  
  i_plant.k_input( k );
  i_plant.y_out( y );
  
  testbench.initiator_socket( i_tlm2rtl.target_socket );	
}
	
};

int sc_main( int argc, char *argv[] )
{
	sc_core::sc_set_time_resolution(1.0, sc_core::SC_FS);

	topl* top = new topl("top_level"); 

	#ifdef TRACE_PLANT
		sca_util::sca_trace_file* atf = sca_util::sca_create_tabular_trace_file(TABULAR_FILE);
		sca_util::sca_trace(atf, top->r   , "r");
		sca_util::sca_trace(atf, top->y   , "y");
		
	#endif
	
	sc_start();
	return 0;
}
