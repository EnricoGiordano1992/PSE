!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!ATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONE!!
!!ATTENZIONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!ATTENZIONE!!
!!ATTENZIONE!!		!!! ATTENZIONE !!!
!!ATTENZIONE!!
!!ATTENZIONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!ATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONE!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


ho compilato in locale con SystemC-AMS a 32 bit (quello a 64 bit non era compatibile), quindi ho scritto:

SCAMS_LIB=$(SCAMS_DIR)/lib-linux

Se non dovesse compilare, sostituire con:

SCAMS_LIB=$(SCAMS_DIR)/lib-linux64
