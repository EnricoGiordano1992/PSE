/*
 * p_plant.cc
 *
 */

#include "p_plant.h"

// ! Constructor
void p_plant::set_attributes (){

	//set_timestep( 20.0, sc_core::SC_MS); 	// module time step assignment of a of 10 ms
	//y_out.set_delay(1.0); 						// set delay of port out to 2 samples

}
// [] rate,tstep,delay
void p_plant::initialize(){

	//costruisco la funzione di trasferimento
	num(0) = 1.0;
	den(0) = 0;
	den(1) = 13;
	den(2) = 1;

}
// [] state
void p_plant::processing (){

//	y_out.write( ltf_nd( num, den, k_input.read(), h0 ) );
	y_out.write( ltf_nd( num, den, k_input.read(), 1 ) );
}
// ! behavior



// [] ac-behavior

