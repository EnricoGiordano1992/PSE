!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!ATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONE!!
!!ATTENZIONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!ATTENZIONE!!
!!ATTENZIONE!!		!!! ATTENZIONE !!!
!!ATTENZIONE!!
!!ATTENZIONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!ATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONEATTENZIONE!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


ho compilato in locale con SystemC-AMS a 32 bit (quello a 64 bit non era compatibile), quindi ho scritto:

SYSC_AMS_LIB=$(SYSTEMC_AMS)/lib-linux

Se non dovesse compilare, sostituire con:

SYSC_AMS_LIB=$(SYSTEMC_AMS)/lib-linux64
